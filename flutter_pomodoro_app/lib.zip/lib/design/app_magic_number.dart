class AppMagicNumber {
  static const int sixty = 60;
}
